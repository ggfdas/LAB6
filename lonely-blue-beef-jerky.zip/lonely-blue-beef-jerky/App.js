

import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  ActivityIndicator,
  SafeAreaView,
  StatusBar,
} from "react-native";

const API_URL =
  "https://6adda25c4e88f1bba4a480fe.mockapi.io/phones";

export default function App() {
  const [activeTab, setActiveTab] = useState("Home");
  const [phones, setPhones] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [keyword, setKeyword] = useState("");

  useEffect(() => {
    fetchPhones();
  }, []);

  async function fetchPhones() {
    try {
      setLoading(true);
      setError("");

      const response = await fetch(API_URL);

      if (!response.ok) {
        throw new Error("Không thể tải dữ liệu từ MockAPI.");
      }

      const data = await response.json();

      if (!Array.isArray(data)) {
        throw new Error("Dữ liệu API không hợp lệ.");
      }

      setPhones(data);
    } catch (e) {
      setError("Không tải được danh sách điện thoại.");
    } finally {
      setLoading(false);
    }
  }

  const filteredPhones = phones.filter((phone) =>
    (phone.name || "")
      .toLowerCase()
      .includes(keyword.trim().toLowerCase())
  );

  function renderPhone({ item }) {
    return (
      <View style={styles.phoneCard}>
        <Text style={styles.phoneName}>{item.name}</Text>
      </View>
    );
  }

  function renderHome() {
    return (
      <View style={styles.page}>
        <Text style={styles.pageTitle}>Trang chủ</Text>

        {loading ? (
          <ActivityIndicator
            size="large"
            color="#F44336"
            style={styles.loading}
          />
        ) : error ? (
          <View style={styles.messageContainer}>
            <Text style={styles.errorText}>{error}</Text>
            <TouchableOpacity
              style={styles.retryButton}
              onPress={fetchPhones}
            >
              <Text style={styles.retryText}>Thử lại</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <FlatList
            data={phones}
            keyExtractor={(item, index) =>
              String(item.id || index)
            }
            renderItem={renderPhone}
            contentContainerStyle={styles.listContent}
            ListEmptyComponent={
              <Text style={styles.emptyText}>
                Không có điện thoại nào.
              </Text>
            }
          />
        )}
      </View>
    );
  }

  function renderSearch() {
    return (
      <View style={styles.page}>
        <Text style={styles.pageTitle}>Tìm kiếm</Text>

        <TextInput
          style={styles.searchInput}
          placeholder="Nhập từ khóa"
          value={keyword}
          onChangeText={setKeyword}
          autoCapitalize="none"
        />

        <FlatList
          data={filteredPhones}
          keyExtractor={(item, index) =>
            String(item.id || index)
          }
          renderItem={renderPhone}
          contentContainerStyle={styles.listContent}
          ListEmptyComponent={
            <Text style={styles.emptyText}>
              Không tìm thấy điện thoại.
            </Text>
          }
        />
      </View>
    );
  }

  function renderProfile() {
    return (
      <View style={styles.profilePage}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>U</Text>
        </View>

        <Text style={styles.profileTitle}>Thông tin cá nhân</Text>
        <Text style={styles.profileText}>Họ tên: Người dùng</Text>
        <Text style={styles.profileText}>
          Email: user@example.com
        </Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar
        backgroundColor="#10265F"
        barStyle="light-content"
      />

      {/* Thanh tiêu đề, đã bỏ chữ Menu - Bài 3 */}
      <View style={styles.header} />

      <View style={styles.content}>
        {activeTab === "Home" && renderHome()}
        {activeTab === "Search" && renderSearch()}
        {activeTab === "Profile" && renderProfile()}
      </View>

      {/* Bottom Tab Navigation */}
      <View style={styles.bottomTab}>
        <TouchableOpacity
          style={styles.tabItem}
          onPress={() => setActiveTab("Home")}
        >
          <Text
            style={[
              styles.tabIcon,
              activeTab === "Home" && styles.activeTabText,
            ]}
          >
            ⌂
          </Text>
          <Text
            style={[
              styles.tabLabel,
              activeTab === "Home" && styles.activeTabText,
            ]}
          >
            Trang chủ
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.tabItem}
          onPress={() => setActiveTab("Search")}
        >
          <Text
            style={[
              styles.tabIcon,
              activeTab === "Search" && styles.activeTabText,
            ]}
          >
            ⚲
          </Text>
          <Text
            style={[
              styles.tabLabel,
              activeTab === "Search" && styles.activeTabText,
            ]}
          >
            Tìm kiếm
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.tabItem}
          onPress={() => setActiveTab("Profile")}
        >
          <Text
            style={[
              styles.tabIcon,
              activeTab === "Profile" && styles.activeTabText,
            ]}
          >
            ♙
          </Text>
          <Text
            style={[
              styles.tabLabel,
              activeTab === "Profile" && styles.activeTabText,
            ]}
          >
            Cá nhân
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F1F1F1",
  },
  header: {
    height: 44,
    backgroundColor: "#10265F",
  },
  content: {
    flex: 1,
  },
  page: {
    flex: 1,
    backgroundColor: "#F1F1F1",
  },
  pageTitle: {
    height: 50,
    backgroundColor: "#FFFFFF",
    paddingHorizontal: 13,
    paddingTop: 15,
    fontSize: 14,
    color: "#222222",
  },
  listContent: {
    padding: 13,
    paddingTop: 12,
  },
  phoneCard: {
    height: 39,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#E1E3E8",
    borderRadius: 7,
    marginBottom: 8,
    justifyContent: "center",
    paddingHorizontal: 11,
  },
  phoneName: {
    fontSize: 12,
    color: "#222222",
  },
  loading: {
    marginTop: 30,
  },
  messageContainer: {
    alignItems: "center",
    marginTop: 25,
  },
  errorText: {
    color: "red",
    marginBottom: 12,
  },
  retryButton: {
    backgroundColor: "#F44336",
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
  },
  retryText: {
    color: "#FFFFFF",
    fontWeight: "bold",
  },
  emptyText: {
    textAlign: "center",
    color: "#777777",
    marginTop: 20,
  },
  searchInput: {
    height: 33,
    marginHorizontal: 13,
    marginTop: 13,
    marginBottom: 8,
    paddingHorizontal: 10,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#E1E3E8",
    borderRadius: 7,
    fontSize: 12,
  },
  profilePage: {
    flex: 1,
    alignItems: "center",
    paddingTop: 45,
    backgroundColor: "#F1F1F1",
  },
  avatar: {
    width: 85,
    height: 85,
    borderRadius: 43,
    backgroundColor: "#F44336",
    justifyContent: "center",
    alignItems: "center",
  },
  avatarText: {
    color: "#FFFFFF",
    fontSize: 35,
    fontWeight: "bold",
  },
  profileTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginTop: 15,
    marginBottom: 15,
  },
  profileText: {
    fontSize: 14,
    marginVertical: 5,
    color: "#444444",
  },
  bottomTab: {
    height: 53,
    backgroundColor: "#FFFFFF",
    borderTopWidth: 1,
    borderTopColor: "#E4E4E4",
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
  },
  tabItem: {
    flex: 1,
    height: "100%",
    alignItems: "center",
    justifyContent: "center",
  },
  tabIcon: {
    fontSize: 23,
    color: "#999999",
    lineHeight: 25,
  },
  tabLabel: {
    fontSize: 10,
    color: "#999999",
    marginTop: 1,
  },
  activeTabText: {
    color: "#F44336",
  },
});
